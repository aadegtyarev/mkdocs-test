#/bin/bash

function ProgressBar {
    let _progress=(${1}*100/${2}*100)/100
    let _done=(${_progress}*4)/10
    let _left=40-$_done
    _fill=$(printf "%${_done}s")
    _empty=$(printf "%${_left}s")

printf "\rProgress : [${_fill// /\#}${_empty// /-}] ${_progress}%%"
		    }

i=0

for j in {9600,115200,57600,38400,19200,4800,2400,1200}; 
     do

for l in {1,2};
   do
    for k in {none,odd,even};
	do
		  ProgressBar ${i} 48; i=$((i+1))
	          for i in {1..247}; do 
                       modbus_client -mrtu /dev/ttyRS485-1 --debug -o 200 -a$i -t3 -r0x80 -b$j -s$l -p$k 
        	    done 2>/dev/null | grep Data: | sed -e 's/ //g' -e 's/\n//' | xargs -I {} printf "\tSpeed:$j\tStop bits:$l\tParity:$k\tModbus address:{}" | grep Data: | sed -e 's/Data://' ; ProgressBar ${i} 11808 ; var=$((i+1))
           done
	done
   done
ProgressBar ${i} 48
